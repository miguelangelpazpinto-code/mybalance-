# Mi Balance — Android, versión de prueba 0.4

Aplicación personal en español. Moneda: USD. Compatible con Android 9 o posterior.

## Uso

1. Abre Mi-Balance.apk en tu Android e instala la aplicación si deseas probarla. Android puede pedir autorización para instalar desde el navegador o gestor de archivos.
2. En Inicio, registra un ingreso o gasto. El balance mensual es ingresos menos gastos registrados, no el saldo real de tus cuentas.
3. En Ajustes → Avisos automáticos, elige las aplicaciones y autoriza el acceso a notificaciones en Android. Solo las apps seleccionadas se procesan. Puedes retirar el permiso cuando quieras.
4. Para estados de cuenta, pulsa Importar y elige PDF, imagen, CSV o TXT. Los archivos Excel deben exportarse a CSV. Los PDF deben estar sin contraseña y tener hasta 40 páginas.
5. Confirma el formato de las fechas y el año. En Revisar, comprueba cada operación con el documento original y corrige importe, fecha, tipo y categoría antes de guardar.
6. Exporta periódicamente tus movimientos confirmados a CSV desde Ajustes. El CSV queda sin cifrar en la ubicación que elijas.

## Alcance real

- Registro, edición y eliminación de ingresos, gastos y transferencias.
- Persistencia SQLite privada en el teléfono. No hay sincronización ni respaldo automático. Desinstalar elimina la base de datos.
- Resumen por mes y desglose por categoría.
- Lectura local de imágenes y PDF mediante OCR. No requiere enviar estados de cuenta a un servidor de análisis.
- Detección de importes con dos decimales, propuestas de categorías y algunas descripciones de ingresos y transferencias.
- Captura de notificaciones nuevas con importes de las apps elegidas. Los correos y SMS se capturan únicamente cuando su app muestra el texto y el importe en una notificación. No descarga buzones ni historiales de SMS. Para mensajes anteriores, usa Compartir o pega el texto.
- Revisión individual antes de sumar estados de cuenta y avisos al balance. Las fotos tomadas con el botón de factura pueden guardarse automáticamente según las reglas descritas más abajo. Filas ya importadas del mismo texto se omiten. Se avisa si existe un movimiento confirmado del mismo tipo, importe y fecha; esto es una sugerencia, no una identificación infalible.

## Limitaciones de esta versión

El OCR y la interpretación de tablas son heurísticos: pueden omitir filas, confundir saldos y cantidades, y clasificar incorrectamente. Si hay varias cantidades en una fila se propone la primera distinta de cero; es obligatorio comprobarla. No hay compatibilidad validada para todos los bancos. Los importes sin decimales pueden omitirse. Las fechas sin año usan el año que indiques; revisa estados que abarcan dos años. No se convierte moneda extranjera. Las notificaciones ocultas, agrupadas, actualizadas o limitadas por Android pueden omitirse o repetirse. No sustituye la comprobación del estado de cuenta.

La app no tiene conexión bancaria ni acceso directo a Gmail/Outlook. Estas integraciones requieren una etapa adicional con el proveedor concreto. No se ha probado en un teléfono físico; debe probarse con documentos de ejemplo antes de confiarle un registro completo.

## Código y compilación

Java 17, Android SDK 35, Gradle 8.10.2, Android Gradle Plugin 8.7.3. Ejecuta `gradle assembleDebug testDebugUnitTest` desde el proyecto con las herramientas instaladas. Establece tu Android SDK en local.properties. La salida es `app/build/outputs/apk/debug/app-debug.apk`.

Fuentes oficiales consultadas:
- https://developer.android.com/reference/android/service/notification/NotificationListenerService
- https://developers.google.com/ml-kit/vision/text-recognition/v2/android
- https://support.google.com/android/answer/12623953

## Verificación realizada

Compilación Android completada; dieciséis pruebas unitarias aprobadas; firma APK verificada. No se ejecutó en emulador ni teléfono físico.

El archivo firma-desarrollo.keystore incluido permite conservar la firma para actualizaciones de esta versión de prueba. Es una clave de desarrollo (alias androiddebugkey; contraseñas android). Conserva este ZIP en privado y no publiques esa clave. Para reconstruir con la misma firma, configura signingConfigs.debug.storeFile con esa ruta.

## Nuevo en 0.2: cámara y suscripciones

Instala el APK sobre la versión anterior; no la desinstales. Se conserva la firma y se amplía la base de datos sin borrar movimientos.

En Inicio → Tomar foto de factura se abre la cámara del teléfono. Tras aceptar la foto, el OCR detecta comercio, fecha, categoría y total. Si hay un comercio identificable, una fecha válida y un único total explícito, se guarda un gasto confirmado automáticamente. La categoría se propone según el comercio. Si falta información, hay varios totales, moneda extranjera reconocida, propinas o un posible duplicado, se guarda como pendiente de revisión. No se añaden individualmente los productos de la factura. El guardado automático es heurístico y puede equivocarse: el resultado muestra Ver / editar para corregir o eliminar el gasto.

En Ajustes → Fotos de facturas puedes elegir mes/día o día/mes. Se mantiene el texto leído en el movimiento; la foto temporal se elimina tras procesarla. Una foto cancelada no genera gastos.

En Inicio → Suscripciones puedes añadir, editar, pausar o eliminar servicios con importe, frecuencia semanal/mensual/anual y próxima fecha. El estimado mensual excluye suscripciones pausadas y no se suma al balance. Registrar pago crea un gasto con fecha de hoy y adelanta un período; Ya está registrado adelanta la fecha sin duplicar un gasto existente. Los cobros no se cargan automáticamente ni se gestionan cancelaciones con proveedores. Se conserva el día original del ciclo tras meses cortos. Eliminar una suscripción no elimina pagos anteriores. Las suscripciones se conservan localmente, pero el CSV de movimientos no incluye su configuración.

La apertura de cámara y la captura/OCR real no se han probado en un dispositivo físico ni emulador. Prueba primero una factura sencilla.

## Nuevo en 0.3: subir fotos o capturas

El botón «Subir foto o captura» aparece en Inicio, Revisar y Ajustes. Abre el selector de imágenes del teléfono (desde la versión 0.4 permite seleccionar varias imágenes). Tras elegirla, se extrae el texto localmente, se confirma el formato de fechas y se detectan movimientos de gastos e ingresos para revisar. Reconoce expresiones como «pago recibido», «payment received», depósitos, reembolsos y algunos importes con signo positivo. La clasificación es una sugerencia: las imágenes con múltiples cantidades, saldos o texto distribuido en varias líneas pueden requerir correcciones. Las capturas no se guardan automáticamente como gastos confirmados; se mantiene el flujo de revisión de documentos. No se solicita acceso completo a la galería.

Compilación y 14 pruebas aprobadas; firma verificada para actualizar la versión anterior. La selección de imágenes y OCR siguen pendientes de prueba en un teléfono físico.

## Nuevo en 0.4: selección múltiple

«Subir fotos o capturas» e «Importar estados de cuenta» permiten marcar varios elementos en el selector de Android. Para una selección múltiple, se elige una sola vez el formato de fecha y el año y se pulsa Importar todos. Usa archivos con el mismo formato de fecha en cada carga. Los documentos se procesan por turnos, mostrando el progreso y el nombre del archivo. Sus movimientos quedan pendientes en Revisar con el nombre del documento como origen. Un archivo ilegible no detiene los restantes. Al terminar se muestra el resumen de movimientos nuevos, filas ya importadas omitidas y archivos que requieren atención. Cada documento se guarda dentro de una transacción. Se mantiene el límite de 40 páginas por PDF y 5 MB por archivo de texto. Mantén la app abierta durante la carga; la tarea no se reanuda automáticamente si Android cierra el proceso, pero los archivos completados conservan sus movimientos.

Los archivos repetidos con el mismo texto reconocido se omiten; distintas fotos del mismo movimiento aún pueden requerir revisión de duplicados. Al seleccionar solo un archivo se conserva la vista previa de texto. La exportación CSV y la cámara mantienen su funcionamiento.

Compilación y 16 pruebas aprobadas, incluidas carga parcial con errores, repetición de archivos y texto vacío. Misma firma de instalación y versión incrementada. El selector y el OCR real no se han probado en un teléfono físico.
Referencia Android: https://developer.android.com/reference/android/content/Intent#EXTRA_ALLOW_MULTIPLE
