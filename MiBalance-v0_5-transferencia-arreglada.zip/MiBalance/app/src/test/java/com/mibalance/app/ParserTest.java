package com.mibalance.app;
import org.junit.Test;import static org.junit.Assert.*;
public class ParserTest {
 @Test public void decimalFormats(){assertEquals(123456,Parser.cents("$1,234.56"));assertEquals(123456,Parser.cents("1.234,56"));assertEquals(1240,Parser.cents("12,40"));}
 @Test public void balanceLinesNotTransactions(){assertTrue(Parser.parse("Beginning balance $400.00\nSaldo final 500,00","Documento",true,2026).isEmpty());}
 @Test public void dateDirection(){assertEquals("2026-09-12",Parser.parse("09/12 Walmart $23.45","Documento",true,2026).get(0).date);assertEquals("2026-12-09",Parser.parse("09/12 Walmart $23.45","Documento",false,2026).get(0).date);}
 @Test public void noInventedDocumentDate(){assertEquals("",Parser.parse("Walmart $23.45","Documento",true,2026).get(0).date);}
 @Test public void incomeAndTransfers(){assertEquals("ingreso",Parser.parse("09/12 Direct deposit 800.00","Documento",true,2026).get(0).type);assertEquals("transferencia",Parser.parse("09/12 Transfer 800.00","Documento",true,2026).get(0).type);}
 @Test public void ocrCategoryAndPending(){Parser.Item i=Parser.parse("09/12 Walmart $23.45 176.55","Documento",true,2026).get(0);assertEquals(2345,i.cents);assertEquals("Supermercado",i.category);assertTrue(i.pending);}
}
