package com.mibalance.app;
import java.util.*;import java.security.*;import java.nio.charset.StandardCharsets;
public class BatchImport {
 public interface Reader<T>{String name(T item);String read(T item)throws Exception;}
 public interface Writer{int save(List<Parser.Item> items,String hash)throws Exception;}
 public interface Progress{void update(int position,int count,String name);}
 public static class Result{public int files,added,duplicates,empty;public List<String> failures=new ArrayList<>();}
 public static String hash(String raw){try{byte[] bytes=MessageDigest.getInstance("SHA-256").digest(raw.getBytes(StandardCharsets.UTF_8));StringBuilder s=new StringBuilder();for(byte b:bytes)s.append(String.format("%02x",b));return s.toString();}catch(Exception e){throw new IllegalStateException(e);}}
 public static <T> Result run(List<T> selections,Reader<T> reader,Writer writer,Progress progress,String source,boolean usDates,int year){
  Result result=new Result();List<T> unique=new ArrayList<>(new LinkedHashSet<>(selections));
  for(int index=0;index<unique.size();index++){
   T selected=unique.get(index);String name="Archivo "+(index+1);
   try{name=reader.name(selected);progress.update(index+1,unique.size(),name);String raw=reader.read(selected);List<Parser.Item> items=Parser.parse(raw,source+" · "+name,usDates,year);int count=writer.save(items,hash(raw));result.files++;result.added+=count;result.duplicates+=items.size()-count;if(items.isEmpty()){result.empty++;result.failures.add(name+": no se detectaron movimientos legibles.");}}
   catch(Exception e){result.failures.add(name+": no se pudo importar. "+(e.getMessage()==null?"Intenta otro archivo.":e.getMessage()));}
  }return result;
 }
}
