package com.mibalance.app;
import android.service.notification.*;import android.app.Notification;import android.os.Bundle;import java.time.*;import java.util.*;
public class MoneyListener extends NotificationListenerService {
 public void onNotificationPosted(StatusBarNotification sbn){
  Set<String> allowed=getSharedPreferences("settings",0).getStringSet("apps",Collections.emptySet());
  if(!allowed.contains(sbn.getPackageName())||(sbn.getNotification().flags&Notification.FLAG_GROUP_SUMMARY)!=0)return;
  Bundle e=sbn.getNotification().extras;CharSequence title=e.getCharSequence(Notification.EXTRA_TITLE,"");CharSequence body=e.getCharSequence(Notification.EXTRA_BIG_TEXT);if(body==null)body=e.getCharSequence(Notification.EXTRA_TEXT,"");
  String text=title+" "+body; if(!text.matches("(?is).*(\\$|USD|compra|purchase|paid|pago|deposit|depósito|cargo|spent|transaction).*"))return;
  String name=sbn.getPackageName();try{name=getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(name,0)).toString();}catch(Exception ignored){}
  List<Parser.Item> items=Parser.parse(text,"Aviso · "+name,true,LocalDate.now().getYear());
  try(Store store=new Store(this)){int index=0;for(Parser.Item i:items){i.date=Instant.ofEpochMilli(sbn.getPostTime()).atZone(ZoneId.systemDefault()).toLocalDate().toString();store.save(i,sbn.getKey()+":"+sbn.getPostTime()+":"+index++);}}
 }
}
