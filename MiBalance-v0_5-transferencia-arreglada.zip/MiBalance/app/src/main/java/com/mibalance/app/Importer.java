package com.mibalance.app;
import android.content.*;import android.net.Uri;import android.graphics.*;import android.graphics.pdf.*;import android.os.*;
import com.google.mlkit.vision.common.InputImage;import com.google.mlkit.vision.text.*;import com.google.mlkit.vision.text.latin.TextRecognizerOptions;import com.google.android.gms.tasks.Tasks;
import java.io.*;import java.util.*;
public class Importer {
 public static String read(Context c,Uri uri)throws Exception{
  String type=c.getContentResolver().getType(uri); if(type==null)type="";
  if(type.startsWith("text/")||type.contains("csv")){try(InputStream in=c.getContentResolver().openInputStream(uri)){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){out.write(b,0,n);if(out.size()>5_000_000)throw new IOException("El texto supera 5 MB.");}return out.toString("UTF-8");}}
  TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
  try{
   if(type.startsWith("image/"))return rows(Tasks.await(recognizer.process(InputImage.fromFilePath(c,uri))));
   if(!type.equals("application/pdf"))throw new IOException("Elige un PDF, imagen, CSV o TXT. Para Excel, exporta primero a CSV.");
   StringBuilder result=new StringBuilder();
   try(ParcelFileDescriptor fd=c.getContentResolver().openFileDescriptor(uri,"r");PdfRenderer pdf=new PdfRenderer(fd)){
    if(pdf.getPageCount()>40)throw new IOException("Importa hasta 40 páginas por archivo. Divide este PDF en partes.");
    for(int p=0;p<pdf.getPageCount();p++){
     try(PdfRenderer.Page page=pdf.openPage(p)){
      float scale=Math.min(2.5f,2400f/Math.max(page.getWidth(),page.getHeight()));
      Bitmap b=Bitmap.createBitmap((int)(page.getWidth()*scale),(int)(page.getHeight()*scale),Bitmap.Config.ARGB_8888);
      try{b.eraseColor(Color.WHITE);page.render(b,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);result.append(rows(Tasks.await(recognizer.process(InputImage.fromBitmap(b,0))))).append('\n');}finally{b.recycle();}
     }
    }
   }return result.toString();
  }finally{recognizer.close();}
 }
 static String rows(Text text){
  ArrayList<Text.Line> lines=new ArrayList<>();for(Text.TextBlock block:text.getTextBlocks())lines.addAll(block.getLines());
  lines.sort(Comparator.comparingInt(l->l.getBoundingBox()==null?0:l.getBoundingBox().centerY()));
  ArrayList<ArrayList<Text.Line>> rows=new ArrayList<>();
  for(Text.Line l:lines){if(l.getBoundingBox()==null)continue;ArrayList<Text.Line> row=rows.isEmpty()?null:rows.get(rows.size()-1);if(row==null||Math.abs(row.get(0).getBoundingBox().centerY()-l.getBoundingBox().centerY())>Math.max(6,l.getBoundingBox().height()/2)){row=new ArrayList<>();rows.add(row);}row.add(l);}
  StringBuilder s=new StringBuilder();for(ArrayList<Text.Line> row:rows){row.sort(Comparator.comparingInt(l->l.getBoundingBox().left));for(Text.Line l:row)s.append(l.getText()).append("  ");s.append('\n');}return s.toString();
 }
}
