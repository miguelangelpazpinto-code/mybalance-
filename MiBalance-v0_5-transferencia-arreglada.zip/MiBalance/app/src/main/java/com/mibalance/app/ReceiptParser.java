package com.mibalance.app;
import java.time.*;import java.util.*;import java.util.regex.*;
public class ReceiptParser {
 public static Parser.Item parse(String raw, boolean usDates){
  Parser.Item item=new Parser.Item();item.raw=raw;item.source="Foto de factura";item.description="Factura por revisar";item.date="";
  String[] lines=raw.split("\\r?\\n");Set<Long> totals=new HashSet<>();Set<String> dates=new HashSet<>();boolean merchant=false;
  Pattern date=Pattern.compile("\\b(\\d{4}-\\d{2}-\\d{2}|\\d{1,2}[/-]\\d{1,2}[/-]\\d{2,4})\\b");
  for(int n=0;n<lines.length;n++){
   String line=lines[n].trim(), lower=line.toLowerCase(Locale.ROOT);
   if(!merchant&&n<6&&line.matches(".*[\\p{L}]{3}.*")&&!line.matches(".*\\d.*")&&!lower.matches(".*(receipt|invoice|factura|welcome|bienvenido|thank|gracias|copy|copia|www\\.|https|ticket|customer|cliente).*")) {item.description=line;merchant=true;}
   Matcher d=date.matcher(line);while(d.find()){try{String ds=d.group();String[] p=ds.split("[-/]");int y,m,day;if(p[0].length()==4){y=Integer.parseInt(p[0]);m=Integer.parseInt(p[1]);day=Integer.parseInt(p[2]);}else{y=Integer.parseInt(p[2]);if(y<100)y+=2000;m=Integer.parseInt(p[usDates?0:1]);day=Integer.parseInt(p[usDates?1:0]);}LocalDate dt=LocalDate.of(y,m,day);if(y>=2000&&!dt.isAfter(LocalDate.now()))dates.add(dt.toString());}catch(Exception ignored){}}
   if(lower.matches("^(grand\\s+total|total(?:\\s+(?:due|paid|usd|a pagar|pagado))?|amount\\s+(?:due|paid))\\s*[:=]?\\s*(?:usd\\s*)?\\$?\\s*[0-9].*")&&!lower.matches(".*(subtotal|sub total|items|artículos|articulos|savings|ahorro|tax|impuesto|discount).*")){
    Matcher a=Parser.AMOUNT.matcher(line);List<Long> values=new ArrayList<>();while(a.find())try{values.add(Parser.cents(a.group()));}catch(Exception ignored){}
    if(values.size()==1&&values.get(0)>0)totals.add(values.get(0));
   }
  }
  if(totals.size()==1)item.cents=totals.iterator().next();
  if(dates.size()==1)item.date=dates.iterator().next();
  item.category=Parser.category(item.description);item.pending=false;
  if(raw.matches("(?is).*(EUR|€|GBP|£|MXN|CAD|Bs\\.|refund|reembolso|devoluci[oó]n|tip|propina|gratuity|suggested).*"))item.pending=true;
  return item;
 }
}
