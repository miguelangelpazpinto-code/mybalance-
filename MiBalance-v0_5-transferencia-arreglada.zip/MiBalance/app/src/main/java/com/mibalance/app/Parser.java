package com.mibalance.app;
import java.util.*;
import java.util.regex.*;
import java.time.*;
import java.time.format.*;
import java.math.BigDecimal;

public class Parser {
 public static class Item { public long id, cents; public String date,description,category="Otros",type="gasto",source="Manual",raw=""; public boolean pending=false; }
 static final Pattern AMOUNT=Pattern.compile("(?<![\\d/])[-+]?\\(?\\$?\\s*\\d+(?:[,.]\\d{3})*[.,]\\d{2}\\)?(?!\\d)");
 static final Pattern DATE=Pattern.compile("\\b(\\d{4}-\\d{2}-\\d{2}|\\d{1,2}[/]\\d{1,2}(?:[/]\\d{2,4})?)\\b");
 public static long cents(String text) {
  String s=text.replaceAll("[^0-9,.-]",""); int dot=s.lastIndexOf('.'),comma=s.lastIndexOf(',');
  if(comma>dot) s=s.replace(".","").replace(',','.'); else s=s.replace(",","");
  return new BigDecimal(s).abs().movePointRight(2).longValueExact();
 }
 public static String category(String text) {
  String s=text.toLowerCase(Locale.ROOT);
  if(s.matches(".*(walmart|kroger|aldi|supermerc|costco|grocery).*")) return "Supermercado";
  if(s.matches(".*(shell|chevron|exxon|gasolina|fuel).*")) return "Transporte";
  if(s.matches(".*(rent|renta|alquiler|apartment).*")) return "Vivienda";
  if(s.matches(".*(electric|internet|water bill|utility|t-mobile|at&t).*")) return "Servicios";
  if(s.matches(".*(restaurant|mcdonald|starbucks|doordash|comida).*")) return "Comida";
  if(s.matches(".*(pharmacy|cvs|walgreens|hospital|doctor).*")) return "Salud";
  if(s.matches(".*(netflix|spotify|hulu).*")) return "Suscripciones";
  return "Otros";
 }
 public static List<Item> parse(String text,String source,boolean usDates,int year) {
  ArrayList<Item> out=new ArrayList<>();
  for(String line:text.split("\\r?\\n")) {
   String lower=line.toLowerCase(Locale.ROOT);
   if(lower.matches(".*(beginning balance|ending balance|opening balance|closing balance|daily balance|balance for the day|account balance|saldo inicial|saldo final|saldo diario|saldo del día|saldo de la cuenta|saldo disponible|available balance|current balance).*")) continue;
   Matcher m=AMOUNT.matcher(DATE.matcher(line).replaceAll(" ")); ArrayList<String> amounts=new ArrayList<>(); while(m.find()) amounts.add(m.group());
   if(amounts.isEmpty()) continue;
   Item item=new Item(); item.raw=line; item.source=source; item.description=line.trim();
   try {for(String amount:amounts){item.cents=cents(amount);if(item.cents>0)break;}} catch(Exception e) {continue;}
   if(item.cents<=0) continue;
   item.date="";
   Matcher d=DATE.matcher(line);
   if(d.find()) { try {
    String ds=d.group(); String[] p=ds.split("[/.-]"); int y=year,mm,dd;
    if(p[0].length()==4){y=Integer.parseInt(p[0]);mm=Integer.parseInt(p[1]);dd=Integer.parseInt(p[2]);}
    else {mm=Integer.parseInt(p[usDates?0:1]);dd=Integer.parseInt(p[usDates?1:0]);if(p.length==3){y=Integer.parseInt(p[2]);if(y<100)y+=2000;}}
    item.date=LocalDate.of(y,mm,dd).toString();
   }catch(Exception ignored){} }
   if(source.startsWith("Aviso"))item.date=LocalDate.now().toString();
   boolean explicitPlus=line.matches(".*[+]\\s*\\$?\\s*\\d.*");
   boolean incoming=lower.matches(".*(payroll|salary|nómina|nomina|depósito|deposit|direct deposit|refund|reembolso|abono|pago recibido|dinero recibido|payment received|received from|credited|income|zelle.*received|zelle.*from|cash app.*received|venmo.*received).*" );
   boolean transfer=lower.matches(".*(transfer|traspaso).*");
   if(transfer)item.type="transferencia";
   else if(explicitPlus || incoming)item.type="ingreso";
   else item.type="gasto";
   item.pending=amounts.size()>1 || (incoming && !explicitPlus && !transfer);
   item.category=category(line);out.add(item);
  }
  return out;
 }
}
